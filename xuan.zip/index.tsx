/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// --- Constants ---
const TOTAL_PLAYERS = 8;
// Siklus lawan pemain, tidak termasuk ronde monster.
const PLAYER_OPPONENT_CYCLE = [7, 6, 3, 4, 2, 8, 5];
const ROMAN_NUMERALS = ["", "I", "II", "III", "IV", "V", "VI", "VII"];

// --- Interfaces ---
interface Player {
  id: number;
  name: string;
  isAlive: boolean;
}

// --- State ---
let players: Player[] = [];
let roundCounter = 0; // Dimulai dari ronde I-4
let playerCycleIndex = 0; // Indeks untuk PLAYER_OPPONENT_CYCLE

// --- DOM Elements ---
const currentRoundEl = document.getElementById('current-round');
const nextOpponentEl = document.getElementById('next-opponent');
const playersGridEl = document.getElementById('players-grid');
const nextRoundBtn = document.getElementById('next-round-btn');
const resetBtn = document.getElementById('reset-btn');

// --- Functions ---
function getRoundName(counter: number): string {
    const absoluteRoundNumber = 4 + counter;
    const stage = Math.ceil(absoluteRoundNumber / 6);
    const roundInStage = absoluteRoundNumber - (stage - 1) * 6;

    if (stage > ROMAN_NUMERALS.length -1) {
        return `Babak ${stage} - Ronde ${roundInStage}`;
    }
    return `${ROMAN_NUMERALS[stage]}-${roundInStage}`;
}

function getRoundInStage(counter: number): number {
    const absoluteRoundNumber = 4 + counter;
    const stage = Math.ceil(absoluteRoundNumber / 6);
    if (stage < 1) return 0;
    return absoluteRoundNumber - (stage - 1) * 6;
}

function getNextOpponent(): { name: string; original?: string } {
    const roundInStage = getRoundInStage(roundCounter);

    // Ronde ke-3 dari setiap babak adalah ronde monster
    if (roundInStage === 3) {
        return { name: 'Monster (Creep)' };
    }

    // Jika tidak, ini adalah ronde pemain
    const livingPlayers = players.filter(p => p.isAlive && p.id !== 1);
    if (livingPlayers.length === 0) {
        return { name: "Hanya Anda yang tersisa!" };
    }

    const originalOpponentId = PLAYER_OPPONENT_CYCLE[playerCycleIndex];
    const originalOpponent = players.find(p => p.id === originalOpponentId);
    const originalOpponentName = originalOpponent ? originalOpponent.name : `Pemain ${originalOpponentId}`;
    
    // Temukan lawan berikutnya yang tersedia dari siklus
    for (let i = 0; i < PLAYER_OPPONENT_CYCLE.length; i++) {
        const currentCycleIndex = (playerCycleIndex + i) % PLAYER_OPPONENT_CYCLE.length;
        const opponentId = PLAYER_OPPONENT_CYCLE[currentCycleIndex];

        const opponent = players.find(p => p.id === opponentId);
        if (opponent && opponent.isAlive) {
            const result = { name: opponent.name };
            if (opponent.id !== originalOpponentId) {
                (result as { name: string; original?: string }).original = originalOpponentName;
            }
            return result;
        }
    }
    
    // Fallback jika semua lawan pemain dalam siklus tereliminasi
    return { name: 'Tidak ada lawan tersedia' };
}

function renderOpponent() {
    if (!nextOpponentEl) return;
    const opponent = getNextOpponent();
    let opponentHtml = `<span>${opponent.name}</span>`;
    if (opponent.original) {
        opponentHtml += `<small style="display: block; font-size: 1rem; color: var(--text-muted-color); margin-top: 0.5rem;">(Seharusnya: ${opponent.original} - Tereliminasi)</small>`;
    }
    nextOpponentEl.innerHTML = opponentHtml;
}

function render() {
    if (!currentRoundEl || !playersGridEl) return;

    // Render Info Ronde
    currentRoundEl.textContent = getRoundName(roundCounter);

    // Render Lawan Selanjutnya
    renderOpponent();

    // Render Grid Pemain
    playersGridEl.innerHTML = '';
    players.forEach(player => {
        const card = document.createElement('div');
        card.className = 'player-card';
        if (!player.isAlive) {
            card.classList.add('eliminated');
        }
        if (player.id === 1) {
            card.classList.add('is-user');
        }

        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.value = player.name;
        nameInput.className = 'player-name-input';
        nameInput.addEventListener('change', (e) => 
            handlePlayerNameChange(player.id, (e.target as HTMLInputElement).value)
        );

        const button = document.createElement('button');
        if (player.id === 1) {
            button.disabled = true;
            button.textContent = 'Ini Anda';
            nameInput.readOnly = true;
        } else {
            button.textContent = player.isAlive ? 'Eliminasikan' : 'Hidupkan';
            button.onclick = () => handleTogglePlayer(player.id);
        }

        card.appendChild(nameInput);
        card.appendChild(button);
        playersGridEl.appendChild(card);
    });
}

function handleNextRound() {
    // Periksa apakah ronde yang kita tinggalkan adalah ronde pemain untuk melanjutkan siklus pemain
    const currentRoundInStage = getRoundInStage(roundCounter);
    if (currentRoundInStage !== 3) {
        playerCycleIndex = (playerCycleIndex + 1) % PLAYER_OPPONENT_CYCLE.length;
    }
    
    roundCounter++;
    render();
}

function handleReset() {
    initializeState();
    render();
}

function handleTogglePlayer(playerId: number) {
    const player = players.find(p => p.id === playerId);
    if (player) {
        player.isAlive = !player.isAlive;
    }
    render();
}

function handlePlayerNameChange(playerId: number, newName: string) {
    const player = players.find(p => p.id === playerId);
    if (player) {
        player.name = newName;
    }
    // Perbarui tampilan lawan jika namanya berubah
    renderOpponent();
}


function initializeState() {
    players = Array.from({ length: TOTAL_PLAYERS }, (_, i) => ({
        id: i + 1,
        name: i === 0 ? `Anda` : `Pemain ${i + 1}`,
        isAlive: true,
    }));
    roundCounter = 0;
    playerCycleIndex = 0;
}

// --- Initialization ---
function main() {
    if (!nextRoundBtn || !resetBtn) return;
    nextRoundBtn.addEventListener('click', handleNextRound);
    resetBtn.addEventListener('click', handleReset);
    initializeState();
    render();
}

main();

export {};